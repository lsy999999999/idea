# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from typing_extensions import Literal, Required, TypedDict

from .._types import FileTypes, SequenceNotStr
from .image_model import ImageModel

__all__ = ["ImageEditParamsBase", "ImageEditParamsNonStreaming", "ImageEditParamsStreaming"]


class ImageEditParamsBase(TypedDict, total=False):
    image: Required[Union[FileTypes, SequenceNotStr[FileTypes]]]
    """The image(s) to edit. Must be a supported image file or an array of images.

    For the GPT image models (`gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
    `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
    `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and
    `gpt-image-2.5-flare-2026-09-08`), each image should be a `png`, `webp`, or
    `jpg` file less than 50MB. You can provide up to 16 images.
    `chatgpt-image-latest` follows the same input constraints as GPT image models.
    """

    prompt: Required[str]
    """A text description of the desired image(s).

    The maximum length is 32000 characters for the GPT image models.
    """

    background: Optional[Literal["transparent", "opaque", "auto"]]
    """Allows to set transparency for the background of the generated image(s).

    Must be one of `transparent`, `opaque`, or `auto` (default value). When `auto`
    is used, the model will automatically determine the best background for the
    image.

    `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
    snapshots, support `opaque` and `transparent` backgrounds. Transparent
    backgrounds are available for supported GPT Image models. For `gpt-image-2` and
    `gpt-image-2-2026-04-21`, this support is in preview. When using `transparent`,
    set the output format to `png` or `webp`.
    """

    complexity: Optional[Literal["low", "medium", "high"]]
    """Computation spent planning the image, independently of rendering quality.

    Uses the image model's configured default when omitted. For SVG output, controls
    the reference image, independently of the SVG author's reasoning.
    """

    frame_count: Optional[int]
    """Number of frames for GIF output.

    Accepts integers from 2 through 16. Defaults to 9 when omitted. Only supported
    with output_format=gif. The requested size must satisfy the selected model's GIF
    size limits. GIF output does not support streaming, partial images, masks, or
    custom output compression. Requires access to the GIF preview for the selected
    model.
    """

    frame_duration_ms: Optional[int]
    """Requested delay per GIF frame, in milliseconds.

    Defaults to 200 when omitted. GIF output rounds to the nearest 10 ms and caps
    the encoded delay at 655,350 ms per frame. Only supported with
    output_format=gif.
    """

    input_fidelity: Optional[Literal["high", "low"]]
    """
    Control how much effort the model will exert to match the style and features,
    especially facial features, of input images. Supports `high` and `low` on
    `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit
    this parameter. Defaults to `low` on supported models.
    """

    markup: FileTypes
    """A transparent PNG overlaid on the first image to guide the edit.

    Must match that image's dimensions after orientation and contain transparent
    pixels. Supports GPT Image 2.5. Cannot be combined with mask.
    """

    mask: FileTypes
    """An additional image whose fully transparent areas (e.g.

    where alpha is zero) indicate where `image` should be edited. If there are
    multiple images provided, the mask will be applied on the first image. Must be a
    valid PNG file, less than 4MB, and have the same dimensions as `image`.
    """

    model: Union[str, ImageModel, None]
    """
    The GPT image model to use for image editing (`gpt-image-1-mini`,
    `gpt-image-1.5`, `gpt-image-2`, `gpt-image-2-2026-04-21`,
    `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`,
    `gpt-image-2.5-flare`, `gpt-image-2.5-flare-2026-09-08`,
    `gpt-image-2.6-sunburst`, `gpt-image-2.6-flare`, or `chatgpt-image-latest`).

    `gpt-image-1` was shut down on October 23, 2026. Use `gpt-image-2.5-sunburst` or
    `gpt-image-2.5-flare` instead.

    Deprecated values:

    - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
      gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
    - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
      image model instead.
    """

    n: Optional[int]
    """The number of images to generate. Must be between 1 and 10."""

    output_compression: Optional[int]
    """The compression level (0-100%) for the generated images.

    This parameter is only supported for the GPT image models with the `webp` or
    `jpeg` output formats, and defaults to 100.
    """

    output_format: Optional[Literal["png", "jpeg", "webp", "gif"]]
    """The format in which the generated images are returned.

    This parameter is only supported for the GPT image models. The default value is
    `png`.
    """

    partial_images: Optional[int]
    """The number of partial images to generate.

    This parameter is used for streaming responses that return partial images. Value
    must be between 0 and 3. When set to 0, the response will be a single image sent
    in one streaming event.

    Note that the final image may be sent before the full number of partial images
    are generated if the full image is generated more quickly.
    """

    quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard"]]
    """The quality of the image that will be generated for GPT image models.

    The GPT image models support `low`, `medium`, and `high`.
    `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
    snapshots, also support `xhigh` and `max`. Defaults to `auto`.

    Deprecated values:

    - "standard": This quality was only supported by retired DALL·E models. Use a
      GPT image quality instead.
    """

    response_format: Optional[Literal["url", "b64_json"]]
    """Legacy response format parameter for retired image models.

    Unsupported for GPT image models, which always return base64-encoded images.
    """

    safety_identifier: Optional[str]
    """
    A stable identifier for an end user in your organization, used for safety
    monitoring and abuse detection. Hash a username or email address to avoid
    sending identifying information. A non-empty value takes precedence over the
    deprecated `user` parameter. If omitted, null, or empty, the API uses `user`
    when available.
    [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).
    """

    size: Union[str, Literal["1024x1024", "1536x1024", "1024x1536", "auto", "256x256", "512x512"], None]
    """The size of the generated images.

    Defaults to `auto`. For `gpt-image-2`, `gpt-image-2-2026-04-21`,
    `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`,
    `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary
    resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`.
    Width and height must both be divisible by 16 and the requested aspect ratio
    must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and
    the maximum supported resolution is `3840x2160`. The requested size must also
    satisfy the model's current pixel and edge limits. The standard sizes
    `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models;
    `auto` is supported for models that allow automatic sizing.

    Deprecated values:

    - "256x256", "512x512": This legacy size suggestion is retained for SDK
      compatibility. Check the selected GPT image model's supported sizes.
    """

    user: str
    """Deprecated: use `safety_identifier` instead.

    This parameter remains accepted for backward compatibility and is used when
    `safety_identifier` is omitted, null, or empty.
    [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).
    """


class ImageEditParamsNonStreaming(ImageEditParamsBase, total=False):
    stream: Optional[Literal[False]]
    """Edit the image in streaming mode.

    Defaults to `false`. See the
    [Image generation guide](https://developers.openai.com/api/docs/guides/image-generation)
    for more information.
    """


class ImageEditParamsStreaming(ImageEditParamsBase):
    stream: Required[Literal[True]]
    """Edit the image in streaming mode.

    Defaults to `false`. See the
    [Image generation guide](https://developers.openai.com/api/docs/guides/image-generation)
    for more information.
    """


ImageEditParams = Union[ImageEditParamsNonStreaming, ImageEditParamsStreaming]
