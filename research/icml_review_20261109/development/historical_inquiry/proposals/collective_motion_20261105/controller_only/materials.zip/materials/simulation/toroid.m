%here both fish have the opprotunity to be non-social
N=1000000;
m=20; %mean velocity
sf=5; %velocity variance
a=2.7; %viscocity
vmax0=27;
T=50;
vmax=vmax0+conv(randn(1,N)*50,ones(1,T)/T,'same'); %vmax(:)=vmax0;
dt=0.03; %timestep of simulation

P=35*4;
dist=5;
pns=0.1; %probability of being non-social
T=100; %non-social interval duration
pns1=nonsocial(N,T,pns); pns2=nonsocial(N,T,pns);

sn=sf/sqrt(2*a);

traj1=zeros(1,N);
v1=zeros(1,N); v1(1)=m;

traj2=zeros(1,N);
v2=waveform(a,vmax0,N,dt);

for i=2:N
    if mod(i,100000)==0
        i
    end
    if pns1(i)==0
        af=force(traj2(i-1),traj1(i-1),a,v2(i-1),v1(i-1),vmax0,P,dist);
        v1(i)=v1(i-1)+af*dt;
    end
    if pns1(i)==1
        v1(i)=nonSocialForce(i,v1(i-1),pns1,30,a,T,vmax(i));
    end
    %v1(i)=rand(1)*30;
    traj1(i)=mod(traj1(i-1)+dt*v1(i),P);
    traj2(i)=mod(traj2(i-1)+dt*v2(i),P);
end

tdt=Vtdist(traj1,traj2,P);
mean(abs(Vtdist(traj1,traj2,P)))

vmax1=30; vmin1=20;
map(traj1,traj2,v1,v2,vmax1,vmin1,P),impixelinfo
