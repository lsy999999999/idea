vmax1=10; vmin1=0;
v=[v1 v2];
ddd=[-tdt tdt]; ddd=ddd(1:end-1);
acc=v(2:end)-v(1:end-1);
v=v(1:end-1); 
vp=[v2 v1]; vp=vp(1:end-1);
ind=(vp<vmax1)&(vp>vmin1);
v=v(ind); acc=acc(ind); ddd=ddd(ind);
dL=20; dr=2;
f=zeros(1,dL/dr*2);
count=zeros(1,dL/dr*2);
for i=1:length(f)
    q=(ddd>(i-1)*dr-20)&(ddd<i*dr-20);
    f(i)=sum(acc(q))/(sum(q)+1);
    count(i)=sum(q);
end

plot(f/dt)