v1=15;

alfa=1/500;
T=3*(20*2)^2*alfa;
fmap=zeros(41,30);
i=0;j=0;
n=5;
d=30*n;
for v02=1:30
    i=i+1;j=0;
    for s=-600:30:600
        j=j+1;
        if s<d
            a=0;
        else if (1/alfa*(log(v1/v02)-(v1-v02)/v1)-(s-d)>0)&&(v02<v1)
                a=0;
            else a=1;
            end
        end
        fmap(j,i)=a*T-alfa*v1^2*(1+2*a);
    end
end

imagesc([1 15],[-30 30],fmap/2), colormap jet,set(gca, 'YDir', 'normal'),caxis([-0.25 0.5]);
        