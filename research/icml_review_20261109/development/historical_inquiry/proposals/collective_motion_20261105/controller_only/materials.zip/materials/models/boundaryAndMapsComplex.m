v1=30; vm=11;

alfa=1/13;
T=30*alfa;
fmap=zeros(41,30);smap=zeros(41,30);
i=0;j=0;
for v02=1:30
    i=i+1;j=0;
    for s=-600:30:600
        j=j+1;
        t=1/alfa*log((v1-(v02-vm))/vm);
        st=v1/alfa*(1-exp(-alfa*t))-vm*t-(v02-vm)/alfa*(1-exp(-alfa*t));
        smap(j,i)=isreal(t)*st;
        if s<0
            a=0;
        else if isreal(st)&&(st-s>0)&&(v02<v1)
                a=0;
            else a=1;
            end
        end
        fmap(j,i)=a*T-alfa*v1;
    end
end

imagesc([1 15],[-30 30],fmap), colormap jet,set(gca, 'YDir', 'normal')%,caxis([-0.25 0.5]);
        