function v=waveform(a,vmax0,N,dt)

v=zeros(1,N); v(1)=13;
t=30;
T=50;
vmax=vmax0+conv(randn(1,N)*50,ones(1,T)/T,'same');

for i=2:N
    if mod(i,t)<t/2
        f=a*(vmax(i)+randn(1)*2-v(i-1))+randn(1)*10;
    else
        f=-a*v(i-1)+randn(1)*10;
    end
    v(i)=max(0,v(i-1)+dt*f);
end

% dv=3;
% acc=v(2:end)-v(1:end-1);
% v=v(1:end-1);
% f=zeros(1,vmax0/dv);
% count=zeros(1,vmax0/dv);
% for i=1:length(f)
%     q=(v>(i-1)*dv)&(v<i*dv);
%     f(i)=sum(acc(q))/(sum(q)+1);
%     count(i)=sum(q);
% end
