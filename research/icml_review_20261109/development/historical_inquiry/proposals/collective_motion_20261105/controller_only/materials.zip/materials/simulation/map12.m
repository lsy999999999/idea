function [force1,count1]=map12(traj1,traj2,v1,v2,vmax,vmin,P)

acc=v1(2:end)-v1(1:end-1);
tdist=Vtdist(traj2,traj1,P);
tdist=tdist(1:end-1);
v1=v1(1:end-1); v2=v2(1:end-1);

ind1=(v1>vmin)&(v1<vmax);

N2=20;
N1=10;
dlim=20;

ind2=(abs(tdist)<dlim);

ind=ind1&ind2;

tdist=tdist(ind);
v1=v1(ind); v2=v2(ind);
acc=acc(ind);

force1=zeros(N2,N1); count1=zeros(N2,N1);

dv=3; vmax=30; dr=2;
for i=1:N2
    for j=1:N1
        q1=(v2<j*dv)&(v2>(j-1)*dv);
        q2=(tdist<i*dr-20.1)&(tdist>(i-1)*dr-20.1);
        force1(i,j)=sum(acc(q1&q2));
        count1(i,j)=sum((q1&q2));
    end
end


