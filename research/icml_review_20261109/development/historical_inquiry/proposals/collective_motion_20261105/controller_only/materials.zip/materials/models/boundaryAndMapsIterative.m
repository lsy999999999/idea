fsum=zeros(41,30);
for v1=0:10

    alfa=1/200;
    T=(30)^2*alfa;
    fmap=zeros(41,30);
    i=0;j=0;
    for v02=1:30
        i=i+1;j=0;
        for s=-600:30:600
            j=j+1;
            if s<0
                a=0;
            else if (1/alfa*(log(v1/v02)-(v1-v02)/v1)-s>0)&&(v02<v1)
                    a=0;
                else a=1;
                end
            end
            fmap(j,i)=a*T-alfa*v1^2;
        end
    end
    fsum=fsum+fmap;
    
end

imagesc([1 15],[-600 600],fsum/11), colormap jet,set(gca, 'YDir', 'normal'),caxis([-T T]);
        