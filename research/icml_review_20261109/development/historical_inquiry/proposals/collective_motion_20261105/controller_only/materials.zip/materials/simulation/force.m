function af=force(xl,xf,a,vl,vf,vmax,P,dist)
%calculate force using pontrjagin model

d=tdist(xl,xf,P);

T=d-dist-1/a*(vf-vl-vl*log(vf/vl));
if d<dist
    af=-a*vf;
else
    if (T<0)&&(vf>vl)
        af=-a*vf;
    else
        af=a*(vmax-vf);
    end
end
