function d=Vtdist(traj1,traj2,P)
d=zeros(1,length(traj1));

for i=1:length(d)
    d(i)=tdist(traj1(i),traj2(i),P);
end