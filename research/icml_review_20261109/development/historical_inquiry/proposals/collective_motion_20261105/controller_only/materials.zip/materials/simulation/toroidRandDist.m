%here both fish have the opprotunity to be non-social

m=20; %mean velocity
sf=5; %velocity variance
a=2.7; %viscocity
vmax=27;
dt=0.03; %timestep of simulation
N=3000000;
P=35*4;
K=100; %dist correlations
dist=3+conv(rand(1,N)-1/2,ones(1,K)/K)*150;
pns=0.2; %probability of being non-social
T=500; %non-social interval duration
pns1=nonsocial(N,T,pns); pns2=nonsocial(N,T,pns);

sn=sf/sqrt(2*a);

traj1=zeros(1,N);
v1=zeros(1,N); v1(1)=m;

traj2=zeros(1,N);
v2=waveform(a,vmax,N,dt);

for i=2:N
    if mod(i,100000)==0
        i
    end
    if pns1(i)==0
        af=force(traj2(i-1),traj1(i-1),a,v2(i-1),v1(i-1),vmax,P,dist(i));
        v1(i)=v1(i-1)+af*dt;
    end
    if pns1(i)==1
        v1(i)=nonSocialForce(i,v1(i-1),pns1,30,a,T,vmax);
    end
    traj1(i)=traj1(i-1)+dt*v1(i);
    traj2(i)=traj2(i-1)+dt*v2(i);
end

tdt=Vtdist(traj1,traj2,P);
median(abs(Vtdist(traj1,traj2,P)))

vmax1=30; vmin1=20;
mapout=map(traj1,traj2,v1,v2,vmax1,vmin1,P);

filt=ones(3,3)/9;
jap=conv2(mapout,filt,'same');
imagesc([0 30*1.05],[-21 21],jap)
caxis([-30 30]),colormap jet,set(gca, 'YDir', 'normal')
%impixelinfo