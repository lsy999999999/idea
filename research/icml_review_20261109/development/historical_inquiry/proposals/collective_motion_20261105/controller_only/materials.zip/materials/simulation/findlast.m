function i0=findlast(pns1,i,T)

i0=floor(i/T)+1;