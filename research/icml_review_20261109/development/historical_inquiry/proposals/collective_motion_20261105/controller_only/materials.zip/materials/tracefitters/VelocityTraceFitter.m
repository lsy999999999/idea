%this function takes the velocity trace of a fish and tries to fit it with
%quadratic traces to minimize the velocity prediction error.


fishnum=11;
%locate trajectory file that has orderr fishnum in the list
list=dir;
z=0; r=0;
while r<fishnum
    z=z+1;
    if strcmp(list(z).name(1:min(12,length(list(z).name))),'trajectories')
        r=r+1;
    end
end

%loading and differentiation
filename=list(z).name;
load(filename)
filt=ones(5,1)/5;
trajectories(:,1,1)=conv(trajectories(:,1,1),filt,'same');
trajectories(:,2,1)=conv(trajectories(:,2,1),filt,'same');
trajectories(:,1,2)=conv(trajectories(:,1,2),filt,'same');
trajectories(:,2,2)=conv(trajectories(:,2,2),filt,'same');

del=100;
vx1=trajectories(del+1:end-del,1,1)-trajectories(del:end-1-del,1,1);
vy1=trajectories(del+1:end-del,1,2)-trajectories(del:end-1-del,1,2);

vx2=trajectories(del+1:end-del,2,1)-trajectories(del:end-1-del,2,1);
vy2=trajectories(del+1:end-del,2,2)-trajectories(del:end-1-del,2,2);

V=sqrt(vx1.^2+vy1.^2);
A=V(2:end)-V(1:end-1);
%look for minima and maxima in velocity signal
maxTrace=zeros(1,length(V));
minTrace=zeros(1,length(V));
for i=2:length(V)-1
    if (V(i)>V(i+1))&&(V(i)>V(i-1))
        maxTrace(i)=10;
    end
    if (V(i)<V(i+1))&&(V(i)<V(i-1))
        minTrace(i)=10;
    end
end
plot(V),hold on,plot(maxTrace),plot(minTrace)

num=nnz(maxTrace);
data=zeros(num,4);
counter=0;z=0;
for i=1:length(V)
    if maxTrace(i)==10&&z==0
        counter=counter+1; z=1;
        data(counter,1)=V(i); data(counter,3)=i;
    end
    if minTrace(i)==10&&z==1
        z=0;
        data(counter,2)=V(i); data(counter,4)=i;
    end
end


error=0; error2=0; alfa=1/300;
for i=1:num
    if data(i,3)~=0&&data(i,4)~=0
        plot(data(i,3):data(i,4),V(data(i,3):data(i,4)),'k')
        plot(data(i,3):data(i,4),V(data(i,3))./(1+alfa*V(data(i,3))*((data(i,3):data(i,4))-data(i,3))),'g')
        s1=V(data(i,3):data(i,4))';
        s2=V(data(i,3))./(1+alfa*V(data(i,3))*((data(i,3):data(i,4))-data(i,3)));
        error=error+sum(abs(s2-s1));
        error2=error2+sum(abs(s1-median(s1)));
    end    
end
error/error2
%%https://www.overleaf.com/5077341zsshfb
