
v0=10;
v1=v0:0.01:3*v0;
s=log(v1/v0)-(v1-v0)./v1;
plot(v1,s*4000)

v1=20;
v0=v1:-0.01:3;
s=log(v0./v1)-(v0-v1)./v0;
figure,plot(v0,-s*4000)

