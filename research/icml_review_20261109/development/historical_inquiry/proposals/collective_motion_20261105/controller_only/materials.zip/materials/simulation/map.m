function [mapout]=map(traj1,traj2,v1,v2,vmax,vmin,P)

[force1,count1]=map12(traj1,traj2,v1,v2,vmax,vmin,P);
[force2,count2]=map12(traj2,traj1,v2,v1,vmax,vmin,P);
mapout=(force1+force2)./(count1+count2)/0.03;