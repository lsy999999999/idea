%the correlator: calculates the average cross-correlatrion across pairs of
%velocities
list=dir;
counter=0;
lag=200;
figure,hold on
v=0;kkk=[];
for i=1:length(list)
    i
    if strcmp(list(i).name(1:min(12,length(list(i).name))),'trajectories')
        counter=counter+1;
        filename=list(i).name;
        load(filename)
        filt=ones(5,1)/5;
        trajectories(:,1,1)=conv(trajectories(:,1,1),filt,'same');
        trajectories(:,2,1)=conv(trajectories(:,2,1),filt,'same');
        trajectories(:,1,2)=conv(trajectories(:,1,2),filt,'same');
        trajectories(:,2,2)=conv(trajectories(:,2,2),filt,'same');
        
        del=100;
        vx1=trajectories(del+1:end-del,1,1)-trajectories(del:end-1-del,1,1);
        vy1=trajectories(del+1:end-del,1,2)-trajectories(del:end-1-del,1,2);

        vx2=trajectories(del+1:end-del,2,1)-trajectories(del:end-1-del,2,1);
        vy2=trajectories(del+1:end-del,2,2)-trajectories(del:end-1-del,2,2);
        
        v1=sqrt(vx1.^2+vy1.^2); v2=sqrt(vx2.^2+vy2.^2);
        zork=correlogram(v1,lag);
        plot(zork)
        v=v+mean(v1)+mean(v2);
        kkk=[kkk v1' v2'];
        length(kkk)
    end
end