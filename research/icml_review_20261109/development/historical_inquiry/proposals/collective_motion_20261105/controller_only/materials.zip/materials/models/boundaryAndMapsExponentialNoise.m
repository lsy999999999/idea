fsum=zeros(41,30);
fmap2=zeros(41,30);
n2=10;
for n=0:n2
    d=30*n;
    for v1=21:30

        alfa=1/13;
        T=(25)*alfa;
        fmap=zeros(41,30);
        i=0;j=0;
        for v02=1:30
            i=i+1;j=0;
            for s=-600:30:600
                j=j+1;
                if s<d
                    a=0;
                else if (1/alfa*((v1-v02)-v02*log(v1/v02))-(s-d)>0)&&(v02<v1)
                        a=0;
                    else a=1;
                    end
                end
                fmap(j,i)=a*T-alfa*v1;
            end
        end
        fsum=fsum+fmap;

    end
    fmap2=fmap2+fsum;
end
scale2=35/1000*30*30; scale1=35/1000*30;
imagesc([0 30*scale1],[-21 21],fsum/11*scale2/(n2+1)), colormap jet,set(gca, 'YDir', 'normal'),caxis([-T*scale2 T*scale2]);
        