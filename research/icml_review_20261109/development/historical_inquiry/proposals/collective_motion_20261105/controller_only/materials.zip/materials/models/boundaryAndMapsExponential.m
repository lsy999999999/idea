fsum=zeros(41,30);
for v1=21:30

    alfa=1/13;
    T=(25)*alfa;
    fmap=zeros(41,30);
    i=0;j=0;
    for v02=1:30
        i=i+1;j=0;
        for s=-600:30:600
            j=j+1;
            if s<0
                a=0;
            else if (1/alfa*((v1-v02)-v02*log(v1/v02))-s>0)&&(v02<v1)
                    a=0;
                else a=1;
                end
            end
            fmap(j,i)=a*T-alfa*v1;
        end
    end
    fsum=fsum+fmap;
    
end
scale2=35/1000*30*30; scale1=35/1000*30;
imagesc([0 30*scale1],[-21 21],fsum/11*scale2), colormap jet,set(gca, 'YDir', 'normal'),caxis([-T*scale2 T*scale2]);
        