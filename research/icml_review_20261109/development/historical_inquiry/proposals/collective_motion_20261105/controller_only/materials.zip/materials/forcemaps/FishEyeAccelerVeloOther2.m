function [velomap,densityMap]=FishEyeAccelerVeloOther2(x,y,ax1,ay1,vx1,vy1,vx2,vy2,range,d,rangev,dv)
%In this modification, I put restrictions on orientaqtions and the ignored
%dimension
%d=10;
vn=[vx1./sqrt(vx1.^2+vy1.^2) vy1./sqrt(vx1.^2+vy1.^2)];
vn2=[-vy1./sqrt(vx1.^2+vy1.^2) vx1./sqrt(vx1.^2+vy1.^2)];
c=(sqrt(vx1.^2+vy1.^2)~=0);
range=floor(range/d)*d;
densityMap=zeros(2*range/d+1,rangev/dv+1); velomap=zeros(2*range/d+1,rangev/dv+1);
position=[x y]; dummyA=[ax1 ay1];
x=sum(position.*vn,2); y=sum(position.*vn2,2);
An=sum(dummyA.*vn,2); At=sum(dummyA.*vn2,2);
x(x<-range)=3000; x(x>range)=3000; a=(x<range);
y(y<-200)=3000; y(y>200)=3000; b=(y<range);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%v=sqrt(vx2.^2+vy2.^2);
v=sum([vx2 vy2].*vn,2);
restrictA=sum([vx2 vy2].*vn,2)./sqrt(sum([vx2 vy2].^2,2)); %this line puts resitrictions on orientation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dd=(v<rangev).*(v>0).*(restrictA>0.7);
x=x(a&b&c&dd); y=y(a&b&c&dd); An=An(a&b&c&dd); At=At(a&b&c&dd);v=v(a&b&c&dd);

for i=1:length(x)
    r1=floor(x(i)/d)+range/d+1;
    r2=floor(v(i)/dv)+1;
    densityMap(r1,r2)=densityMap(r1,r2)+1;
    velomap(r1,r2)=velomap(r1,r2)+An(i);   
end


    

