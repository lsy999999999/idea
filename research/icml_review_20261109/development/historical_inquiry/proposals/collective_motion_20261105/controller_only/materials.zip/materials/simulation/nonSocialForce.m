function v=nonSocialForce(i,vPast,pns1,t,a,T,vmax)
dt=0.03;
i0=findlast(pns1,i,T);
is=i-i0+1;

if mod(is,t)<t/2
        f=a*(vmax+randn(1)*2-vPast)+randn(1)*10;
else
    f=-a*vPast+randn(1)*10;
end
v=vPast+dt*f;