%this script makes a map that takes into account velocity for both self and
%other as well as 1D positional information. Used to estimate how much data
%has an aberrant origin

list=dir;
range=600; d=60;
rangev=30; dv=3;
densityC=zeros(2*range/d+1,rangev/dv+1); 
veloC=zeros(2*range/d+1,rangev/dv+1);
vmax=10; vmin=0;
avVelo=zeros(13,2);
counter=0;
for i=1:length(list)
    i
    if strcmp(list(i).name(1:min(12,length(list(i).name))),'trajectories')
        counter=counter+1;
        filename=list(i).name;
        load(filename)
        filt=ones(5,1)/5;
        trajectories(:,1,1)=conv(trajectories(:,1,1),filt,'same');
        trajectories(:,2,1)=conv(trajectories(:,2,1),filt,'same');
        trajectories(:,1,2)=conv(trajectories(:,1,2),filt,'same');
        trajectories(:,2,2)=conv(trajectories(:,2,2),filt,'same');
        
        del=100;
        vx1=trajectories(del+1:end-del,1,1)-trajectories(del:end-1-del,1,1);
        vy1=trajectories(del+1:end-del,1,2)-trajectories(del:end-1-del,1,2);

        vx2=trajectories(del+1:end-del,2,1)-trajectories(del:end-1-del,2,1);
        vy2=trajectories(del+1:end-del,2,2)-trajectories(del:end-1-del,2,2);

        x=trajectories(del:end-del,2,1)-trajectories(del:end-del,1,1);
        y=trajectories(del:end-del,2,2)-trajectories(del:end-del,1,2);

        ax1=vx1(2:end)-vx1(1:end-1);
        ay1=vy1(2:end)-vy1(1:end-1);
        ax2=vx2(2:end)-vx2(1:end-1);
        ay2=vy2(2:end)-vy2(1:end-1);
        x=x(2:end-1); y=y(2:end-1); %rememmber the change here from x=x(1:end-2); y=y(1:end-2);
        vx1=vx1(1:end-1); vy1=vy1(1:end-1);
        vx2=vx2(1:end-1); vy2=vy2(1:end-1);
        v=sqrt(vx1.^2+vy1.^2); uInd=(v<vmax)&(v>vmin); avVelo(counter,1)=mean(v);
        
        [velomap,densityMap]=FishEyeAccelerVeloOther(x(uInd),y(uInd),ax1(uInd),ay1(uInd),vx1(uInd),vy1(uInd),vx2(uInd),vy2(uInd),range,d,rangev,dv);
        veloC=veloC+velomap;
        densityC=densityC+densityMap;
        
        v=sqrt(vx2.^2+vy2.^2); uInd=(v<vmax)&(v>vmin); avVelo(counter,2)=mean(v);
        
        [velomap,densityMap]=FishEyeAccelerVeloOther(-x(uInd),-y(uInd),ax2(uInd),ay2(uInd),vx2(uInd),vy2(uInd),vx1(uInd),vy1(uInd),range,d,rangev,dv);
        veloC=veloC+velomap;
        densityC=densityC+densityMap;
    end
end

imagesc([0 15],[-30 30],veloC./(densityC+50)/2),caxis([-0.35 0.35]),colormap jet,set(gca, 'YDir', 'normal')
jap=veloC./(densityC+50);




