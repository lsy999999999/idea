function pns1=nonsocial(N,T,pns)

pns1=zeros(1,N);

for i=1:floor(N/T)
    if rand(1)<pns
        pns1((i-1)*T+1:i*T)=1;
    end
end