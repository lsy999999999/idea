function d=tdist(xl,xf,P)

if xl>xf
    d1=xl-xf;
    if d1<P/2
        d=d1;
    else
        d=-(P-d1);
    end
end

if xl<=xf
    d1=-(xf-xl);
    if -d1<P/2
        d=d1;
    else
        d=(P+d1);
    end
end