function zork=correlogram(v1,lag)

zork=zeros(1,lag+1);

for i=0:lag
    a=v1(1:end-i); b=v1(i+1:end);
    dummy=corrcoef(a,b);
    zork(i+1)=dummy(1,2);
end
